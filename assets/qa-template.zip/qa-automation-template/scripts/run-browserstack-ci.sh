#!/usr/bin/env bash
set -euo pipefail
# Linux CI only. Never enable shell tracing: the tunnel consumes an account key.
: "${BROWSERSTACK_USERNAME:?Missing BrowserStack username}"
: "${BROWSERSTACK_ACCESS_KEY:?Missing BrowserStack access key}"
mkdir -p reports
TEMP_DIR=$(mktemp -d)
FIXTURE_PID=''
TUNNEL_PID=''
cleanup() {
  if [[ -n "$TUNNEL_PID" ]]; then kill "$TUNNEL_PID" 2>/dev/null || true; wait "$TUNNEL_PID" 2>/dev/null || true; fi
  if [[ -n "$FIXTURE_PID" ]]; then kill "$FIXTURE_PID" 2>/dev/null || true; wait "$FIXTURE_PID" 2>/dev/null || true; fi
  rm -rf -- "$TEMP_DIR"
}
trap cleanup EXIT
export FIXTURE_PORT=4173
node fixtures/server.mjs > reports/fixture.log 2>&1 &
FIXTURE_PID=$!
node --input-type=module -e 'let ready=false;for(let i=0;i<60;i++){try{if((await fetch("http://127.0.0.1:4173/health")).ok){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,250))}if(!ready)process.exit(1)'
curl --fail --silent --show-error --location --retry 2 https://www.browserstack.com/browserstack-local/BrowserStackLocal-linux-x64.zip --output "$TEMP_DIR/local.zip"
unzip -q "$TEMP_DIR/local.zip" -d "$TEMP_DIR"
export BROWSERSTACK_LOCAL_IDENTIFIER="qa-${GITHUB_RUN_ID:-manual}-${GITHUB_RUN_ATTEMPT:-1}"
# Restrict the tunnel to the fixture port; do not combine --only with --force-local.
"$TEMP_DIR/BrowserStackLocal" --key "$BROWSERSTACK_ACCESS_KEY" --local-identifier "$BROWSERSTACK_LOCAL_IDENTIFIER" --only '127.0.0.1,4173,0' --only-automate > "$TEMP_DIR/tunnel.log" 2>&1 &
TUNNEL_PID=$!
READY=false
for i in {1..60}; do
  kill -0 "$TUNNEL_PID" 2>/dev/null || { echo 'BrowserStack tunnel exited; check account access.'; exit 1; }
  if grep -q 'You can now access your local server' "$TEMP_DIR/tunnel.log"; then READY=true; break; fi
  sleep 1
done
[[ "$READY" == true ]] || { echo 'BrowserStack tunnel readiness timed out.'; exit 1; }
export ALLOW_CLOUD=true BROWSERSTACK_LOCAL=true CLOUD_BASE_URL='http://127.0.0.1:4173/'
export BROWSERSTACK_BUILD_NAME="QA portfolio Actions ${GITHUB_RUN_ID:-manual}"
npm run test:cloud
