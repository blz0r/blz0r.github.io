import 'dotenv/config';
import { spawn } from 'node:child_process';
import { mkdir } from 'node:fs/promises';
import { startFixture } from '../fixtures/server.mjs';

const mode = process.argv[2] || 'all';
if (!['all', 'api', 'web'].includes(mode)) throw new Error(`Unknown mode: ${mode}`);
const port = Number(process.env.FIXTURE_PORT || 4173);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('FIXTURE_PORT must be a valid port');
// Local commands deliberately own the fixture URL. External runs have a separate command.
process.env.BASE_URL = `http://127.0.0.1:${port}`;
await mkdir('reports/junit', { recursive: true });
const server = await startFixture(port);
async function run(args) {
  const child = spawn(process.execPath, args, { stdio: 'inherit', env: process.env });
  return await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', code => resolve(code ?? 1));
  });
}
let result = 0;
try {
  if (mode !== 'web') result ||= await run([
    '--test', '--test-reporter=spec', '--test-reporter=junit',
    '--test-reporter-destination=stdout', '--test-reporter-destination=reports/junit/api.xml',
    'tests/api/local-api.test.mjs'
  ]);
  // Still run browser coverage after an API assertion failure.
  if (mode !== 'api') {
    const webResult = await run(['node_modules/@wdio/cli/bin/wdio.js', 'run', 'config/wdio.local.ts']);
    result ||= webResult;
  }
} finally {
  await new Promise(resolve => server.close(resolve));
}
process.exitCode = result;
