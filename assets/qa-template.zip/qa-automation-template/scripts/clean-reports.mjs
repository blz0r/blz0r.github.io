import { rm } from 'node:fs/promises';
// Fixed relative output folder only; no environment-controlled deletion target.
await rm(new URL('../reports/', import.meta.url), { recursive: true, force: true });
