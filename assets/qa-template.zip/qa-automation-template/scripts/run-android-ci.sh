#!/usr/bin/env bash
set -Eeuo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

reports_dir="$repo_root/reports"
mkdir -p "$reports_dir/android" "$reports_dir/junit" "$reports_dir/allure-results" "$reports_dir/screenshots"
apk_path="$RUNNER_TEMP/ApiDemos-debug.apk"
apk_url="https://github.com/appium/android-apidemos/releases/download/v6.0.18/ApiDemos-debug.apk"
apk_sha256="a9eecf37b26cd084855c530db81c2bb1b91f4c1b095a04f47aa7c20e2791f686"
appium_log="$reports_dir/android/appium-server.log"
appium_pid=""

collect_android_logs() {
  adb logcat -d > "$reports_dir/android/logcat.txt" 2>&1 || true
  adb shell getprop > "$reports_dir/android/device-properties.txt" 2>&1 || true
}

cleanup() {
  result=$?
  if [[ "$result" -ne 0 ]]; then
    collect_android_logs
  fi
  if [[ -n "$appium_pid" ]]; then
    kill "$appium_pid" 2>/dev/null || true
    wait "$appium_pid" 2>/dev/null || true
  fi
  exit "$result"
}
trap cleanup EXIT

echo "Downloading the pinned Appium ApiDemos sample"
curl --fail --location --retry 3 --retry-delay 2 "$apk_url" --output "$apk_path"
printf '%s  %s\n' "$apk_sha256" "$apk_path" | sha256sum --check --status

npm ci
npm run typecheck
npm install --global appium@3.8.0
appium driver install uiautomator2@8.7.0
appium driver list --installed

timeout 60 adb wait-for-device
for attempt in $(seq 1 120); do
  if [[ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" == "1" ]]; then
    break
  fi
  if [[ "$attempt" -eq 120 ]]; then
    echo "Android emulator did not finish booting within 120 seconds" >&2
    exit 1
  fi
  sleep 1
done
adb devices -l

appium --address 127.0.0.1 --port 4723 --log "$appium_log" --log-level info &
appium_pid=$!
for attempt in $(seq 1 60); do
  if curl --fail --silent http://127.0.0.1:4723/status > /dev/null; then
    break
  fi
  if ! kill -0 "$appium_pid" 2>/dev/null; then
    echo "Appium server exited before becoming ready" >&2
    exit 1
  fi
  if [[ "$attempt" -eq 60 ]]; then
    echo "Appium server did not become ready within 60 seconds" >&2
    exit 1
  fi
  sleep 1
done

export ALLOW_MOBILE="true"
export ANDROID_APP="$apk_path"
export ANDROID_UDID="emulator-5554"
export ANDROID_DEVICE_NAME="GitHub Actions Android Emulator"
npm exec -- wdio run config/wdio.apidemos.ts

