import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

// Deliberately synthetic, public demo values. This is not a production auth system.
export const DEMO_USER = { email: 'learner@example.test', password: 'demo-pass' };
export const TASKS = [
  { id: 1, title: 'Review acceptance criteria', completed: true },
  { id: 2, title: 'Run regression checks', completed: false }
];

const json = (response, status, body) => {
  response.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  response.end(JSON.stringify(body));
};

export async function startFixture(port = 4173) {
  const html = await readFile(new URL('./index.html', import.meta.url));
  const server = http.createServer(async (request, response) => {
    try {
      const path = new URL(request.url, 'http://127.0.0.1').pathname;
      if (request.method === 'GET' && path === '/health') return json(response, 200, { status: 'ok' });
      if (request.method === 'GET' && path === '/api/tasks') return json(response, 200, { tasks: TASKS });
      if (request.method === 'POST' && path === '/api/login') {
        let raw = '';
        for await (const chunk of request) {
          raw += chunk;
          if (raw.length > 4096) return json(response, 413, { error: 'Body too large' });
        }
        let input;
        try { input = JSON.parse(raw); }
        catch { return json(response, 400, { error: 'Invalid JSON' }); }
        if (!input || typeof input.email !== 'string' || typeof input.password !== 'string') {
          return json(response, 400, { error: 'Email and password are required' });
        }
        if (input.email !== DEMO_USER.email || input.password !== DEMO_USER.password) {
          return json(response, 401, { error: 'Email or password is incorrect' });
        }
        return json(response, 200, { user: { name: 'Demo Learner', email: DEMO_USER.email } });
      }
      if (request.method === 'GET' && path === '/') {
        response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        return response.end(html);
      }
      return json(response, 404, { error: 'Not found' });
    } catch {
      if (!response.headersSent) json(response, 500, { error: 'Fixture request failed' });
      else response.end();
    }
  });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', resolve);
  });
  return server;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const port = Number(process.env.FIXTURE_PORT || 4173);
  const server = await startFixture(port);
  console.log(`Synthetic fixture: http://127.0.0.1:${port}`);
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close());
}
