# QA automation template

An original practice project for reusable QA work. It uses a synthetic login/dashboard and a local JSON API; all data and test credentials are invented. The fixture is intentionally simple and is not a production authentication implementation.

The primary stack is **TypeScript + WebdriverIO 10 + Cucumber** for browser checks and **JavaScript + Node's test runner** for API checks. Separate [Java](java/README.md) and [Python](python/README.md) examples use the same app. Start with one stack, then compare how the same requirements are expressed.

## Quickstart

Install Node **24 LTS** and have Chrome available. The supported Node engine also permits 22.19+ in the 22 line and 26+. Node 18 and 20 are not supported by this WebdriverIO version.

```sh
npm ci
npm run typecheck
npm test
```

`npm test` starts an isolated loopback fixture, runs API and headless browser tests, then closes the server. It requires no cloud account. The initial browser/driver setup can download free Chrome tooling through WebdriverIO. Set `CHROME_BINARY` if Chrome needs an explicit location. If port 4173 is occupied, set `FIXTURE_PORT` to a free port. Run commands from this project directory.

```sh
npm run test:api
npm run test:web
```

To explore the app manually, run `npm run fixture` and open `http://127.0.0.1:4173`. The public demo values are `learner@example.test` and `demo-pass`.

## Adapt the template

Copy `.env.example` to `.env` only when overrides are needed. `.env` is ignored. Local test commands own their fixture URL, so `BASE_URL` cannot redirect `npm test` to a real service. To test an authorized app with matching steps, start it separately, set `BASE_URL`, adapt page objects and expectations, and run `npm run test:web:external`.

- `fixtures/`: original HTML and Node HTTP API.
- `tests/features/`: readable acceptance scenarios and tags.
- `tests/pages/`: selectors and browser actions.
- `tests/steps/`: scenario assertions.
- `tests/api/`: API status, body and contract assertions in JavaScript.
- `config/`: local browser and separate opt-in cloud/mobile configurations.
- `docs/`: usage, test planning, defect reporting and portfolio context.

Use stable test IDs, keep assertions focused on requirements, and use your own test data. Review screenshots and reports before publishing them because adapted apps may display sensitive information.

## Reports and CI

Local runs write JUnit XML to `reports/junit/` and browser Allure result JSON to `reports/allure-results/`. Failed browser scenarios save PNGs under `reports/screenshots/`; the Allure reporter also captures WebDriver screenshot events. API tests produce JUnit, not Allure. `npm run clean:reports` removes this generated output. Clean between runs when collecting a single run for Allure; otherwise result files accumulate.

The pinned Node-based **Allure 3 CLI** generates separate local HTML reports with `npm run report:web`, `npm run report:java`, and `npm run report:python` after running the corresponding tests. Outputs are `reports/allure-web/`, `reports/allure-java/`, and `reports/allure-python/`; each contains `index.html`. The report commands do not open a browser. For interactive serving, use the CLI's `open` command with `--host 127.0.0.1`. Java is not required for report generation. HTML generation has been validated for all three stacks. The narrow `dompurify` override selects patched 3.4.17 because Allure 3.22.1 pins vulnerable 3.4.16 upstream; review this override when upgrading Allure.

The included `local-qa.yml` workflow runs the local API/browser checks on push, pull request and manual dispatch, with read-only repository permissions. It preserves reports even when checks fail. It never invokes cloud or mobile commands. Hosted web/API, Java and Python jobs have passed; see the linked runs and artifact checks in [the verification record](docs/VALIDATION.md).

## Optional cloud and Android examples

`npm run test:cloud` is disabled unless `ALLOW_CLOUD=true` and the required BrowserStack variables are supplied. It supports an authorized HTTPS deployment at `CLOUD_BASE_URL`. The separate manual BrowserStack workflow instead hosts the fixture on a disposable runner and uses a tunnel restricted to that fixture's host and port. It requires repository secrets and may consume provider allowance. No account is created. It is never called by the default tests or push/PR workflows. See [BrowserStack setup](docs/BROWSERSTACK_QA.md).

`npm run test:mobile` is disabled unless `ALLOW_MOBILE=true`. It connects to an already running **local** Appium server with UiAutomator2, Android SDK/emulator or device, an authorized sample APK at an absolute `ANDROID_APP` path, and `ANDROID_UDID`, `ANDROID_DEVICE_NAME`, `ANDROID_READY_ID`. It asserts that the configured accessibility ID is visible after launch. Appium and device tooling are not installed by this project. `noReset: false` means the sample app may be reset. Use an expendable test device/app.

BrowserStack is configured but has not been executed with a provider account. The generic local-device Android configuration remains an adaptation example.

The separate manual [Android Appium workflow](docs/ANDROID_QA.md) provisions a disposable GitHub-hosted emulator and runs two UI scenarios against Appium's third-party ApiDemos sample. It requires no local Android installation or BrowserStack account. Both scenarios passed in a verified hosted run; see [the verification record](docs/VALIDATION.md) and [failure diagnosis example](docs/DEBUGGING_EXAMPLE.md).

## Verified scope

On 2026-10-25 (America/Chicago), Node 24.22.1 and headless Chrome 156 on Windows completed TypeScript checking, **7 API tests**, and **3 Cucumber scenarios / 14 steps**. Coverage includes successful sign-in/task display/sign-out, two invalid credential cases, API health, valid/invalid login, missing fields, malformed JSON, task contract and 404. This is functional example coverage; it does not establish production security, accessibility, load or exhaustive browser coverage. See the Java/Python guides for their separate verification status.

## Official references

See the [usage guide](docs/USAGE_GUIDE.md), [test plan](docs/TEST_PLAN.md), [defect report template](docs/BUG_REPORT_TEMPLATE.md), [portfolio context](docs/PORTFOLIO_CONTEXT.md), and [verification record](docs/VALIDATION.md). The additional `cross-language.yml` workflow runs Java and Python checks and preserves their reports.

- [WebdriverIO setup](https://webdriver.io/docs/gettingstarted/) and [TypeScript](https://webdriver.io/docs/typescript/)
- [Cucumber integration](https://webdriver.io/docs/frameworks/), [JUnit](https://webdriver.io/docs/junit-reporter/) and [Allure reporter](https://webdriver.io/docs/allure-reporter/)
- [BrowserStack WebdriverIO guidance](https://www.browserstack.com/docs/automate/selenium/getting-started/nodejs/webdriverio)
- [Appium quickstart](https://appium.io/docs/en/latest/quickstart/)

Package versions are reproducible through `package-lock.json`. No license or employment claims are supplied; choose your distribution terms before publishing.
