import { test } from 'node:test';
import assert from 'node:assert/strict';

const baseUrl = process.env.BASE_URL || 'http://127.0.0.1:4173';
const login = body => fetch(new URL('/api/login', baseUrl), {
  method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
});

test('health endpoint identifies a ready fixture', async () => {
  const response = await fetch(new URL('/health', baseUrl));
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type'), /application\/json/);
  assert.deepEqual(await response.json(), { status: 'ok' });
});
test('valid synthetic credentials return the expected public user fields', async () => {
  const response = await login({ email: 'learner@example.test', password: 'demo-pass' });
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { user: { name: 'Demo Learner', email: 'learner@example.test' } });
});
test('wrong credentials return 401 and no user object', async () => {
  const response = await login({ email: 'learner@example.test', password: 'incorrect' });
  assert.equal(response.status, 401);
  assert.deepEqual(await response.json(), { error: 'Email or password is incorrect' });
});
test('missing fields return a client validation error', async () => {
  const response = await login({ email: 'learner@example.test' });
  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'Email and password are required' });
});
test('malformed JSON returns 400', async () => {
  const response = await fetch(new URL('/api/login', baseUrl), {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{invalid'
  });
  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'Invalid JSON' });
});
test('task contract includes stable IDs, titles and boolean states', async () => {
  const response = await fetch(new URL('/api/tasks', baseUrl));
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { tasks: [
    { id: 1, title: 'Review acceptance criteria', completed: true },
    { id: 2, title: 'Run regression checks', completed: false }
  ] });
});
test('unknown routes return a JSON 404', async () => {
  const response = await fetch(new URL('/missing', baseUrl));
  assert.equal(response.status, 404);
  assert.deepEqual(await response.json(), { error: 'Not found' });
});
