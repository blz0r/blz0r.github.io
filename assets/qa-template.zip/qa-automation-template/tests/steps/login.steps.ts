import { Given, When, Then } from '@wdio/cucumber-framework';
import { expect } from '@wdio/globals';
import LoginPage from '../pages/login.page.ts';
import DashboardPage from '../pages/dashboard.page.ts';

Given('I open the practice login page', async () => { await LoginPage.open(); });
When('I sign in with {string} and {string}', async (email: string, password: string) => {
  await LoginPage.signIn(email, password);
});
Then('I see the welcome message {string}', async (message: string) => {
  await expect(DashboardPage.panel).toBeDisplayed();
  await expect(DashboardPage.welcome).toHaveText(message);
});
Then('I see the two practice tasks', async () => {
  await expect(DashboardPage.tasks).toBeElementsArrayOfSize(2);
  await expect(DashboardPage.tasks).toHaveText(['Review acceptance criteria', 'Run regression checks']);
});
When('I sign out', async () => { await DashboardPage.signOut(); });
Then('I see an empty login form', async () => {
  await expect(LoginPage.panel).toBeDisplayed();
  await expect(LoginPage.email).toHaveValue('');
  await expect(LoginPage.password).toHaveValue('');
  await expect(DashboardPage.panel).not.toBeDisplayed();
});
Then('I see the error {string}', async (message: string) => {
  await expect(LoginPage.error).toBeDisplayed();
  await expect(LoginPage.error).toHaveText(message);
});
Then('the dashboard stays hidden', async () => { await expect(DashboardPage.panel).not.toBeDisplayed(); });
