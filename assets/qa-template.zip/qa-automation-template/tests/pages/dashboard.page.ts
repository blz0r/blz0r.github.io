import { $, $$ } from '@wdio/globals';

class DashboardPage {
  get panel() { return $('[data-testid="dashboard"]'); }
  get welcome() { return $('[data-testid="welcome"]'); }
  get tasks() { return $$('[data-testid="tasks"] li'); }
  async signOut() { await $('[data-testid="sign-out"]').click(); }
}
export default new DashboardPage();
