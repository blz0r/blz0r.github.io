import { $, browser } from '@wdio/globals';

class LoginPage {
  get email() { return $('[data-testid="email"]'); }
  get password() { return $('[data-testid="password"]'); }
  get submit() { return $('[data-testid="sign-in"]'); }
  get error() { return $('[data-testid="error"]'); }
  get panel() { return $('[data-testid="login-panel"]'); }
  async open() { await browser.url('/'); }
  async signIn(email: string, password: string) {
    await this.email.setValue(email);
    await this.password.setValue(password);
    await this.submit.click();
  }
}
export default new LoginPage();
