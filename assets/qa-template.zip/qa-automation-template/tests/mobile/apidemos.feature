@mobile @sample-app
Feature: Appium Android sample app checks
  These scenarios exercise the third-party Appium ApiDemos sample APK on a hosted emulator.

  Scenario: Navigate into the Views examples
    When I open the Views examples
    Then the Views examples screen is visible

  Scenario: Enter a name and password in an alert dialog
    When I open the text entry alert dialog
    And I enter sample user details
    Then the dialog displays the entered name and password field
