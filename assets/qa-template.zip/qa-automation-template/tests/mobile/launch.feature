@mobile
Feature: Authorized Android sample app
  Scenario: A configured sample app launches
    Then the configured app readiness element is visible
