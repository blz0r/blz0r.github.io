import { Then } from '@wdio/cucumber-framework';
import { $, expect } from '@wdio/globals';

Then('the configured app readiness element is visible', async () => {
  // Appium accessibility selector; set this to an ID present in your own sample app.
  await expect($(`~${process.env.ANDROID_READY_ID}`)).toBeDisplayed();
});
