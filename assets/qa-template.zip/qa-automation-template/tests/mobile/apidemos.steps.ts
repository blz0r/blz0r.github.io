import { Before, When, Then } from '@wdio/cucumber-framework';
import { $, browser, expect } from '@wdio/globals';

Before(async () => {
  const appId = 'io.appium.android.apis';
  await browser.terminateApp(appId);
  await browser.activateApp(appId);
  await expect($('~App')).toBeDisplayed();
});

When('I open the Views examples', async () => {
  await $('~Views').click();
});

Then('the Views examples screen is visible', async () => {
  await expect($('~Controls')).toBeDisplayed();
});

When('I open the text entry alert dialog', async () => {
  await $('~App').click();
  await $('~Alert Dialogs').click();
  await $('~Text Entry dialog').click();
});

When('I enter sample user details', async () => {
  await $('id=io.appium.android.apis:id/username_edit').setValue('CI Sample User');
  await $('id=io.appium.android.apis:id/password_edit').setValue('sample-password');
});

Then('the dialog displays the entered name and password field', async () => {
  await expect($('id=io.appium.android.apis:id/username_edit')).toHaveText('CI Sample User');
  await expect($('id=io.appium.android.apis:id/password_edit')).toBeDisplayed();
});
