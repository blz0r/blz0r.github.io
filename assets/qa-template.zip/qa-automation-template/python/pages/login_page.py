"""Page objects for the synthetic application; replace selectors for your app."""
import allure
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


class LoginPage:
    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.wait = WebDriverWait(driver, 10)

    @staticmethod
    def selector(test_id):
        return By.CSS_SELECTOR, f'[data-testid="{test_id}"]'

    @allure.step("Open the login page")
    def open(self):
        self.driver.get(self.base_url)
        self.wait.until(EC.visibility_of_element_located(self.selector("login-panel")))
        return self

    @allure.step("Submit the synthetic login form")
    def sign_in(self, email, password):
        # Values are intentionally not included in the Allure step title.
        self.driver.find_element(*self.selector("email")).send_keys(email)
        self.driver.find_element(*self.selector("password")).send_keys(password)
        self.driver.find_element(*self.selector("sign-in")).click()

    def welcome(self):
        return self.wait.until(EC.visibility_of_element_located(self.selector("welcome"))).text

    def error(self):
        return self.wait.until(EC.visibility_of_element_located(self.selector("error"))).text

    @allure.step("Sign out")
    def sign_out(self):
        self.driver.find_element(*self.selector("sign-out")).click()
        self.wait.until(EC.visibility_of_element_located(self.selector("login-panel")))

    def login_is_visible(self):
        return self.driver.find_element(*self.selector("login-panel")).is_displayed()

    def email_value(self):
        return self.driver.find_element(*self.selector("email")).get_attribute("value")
