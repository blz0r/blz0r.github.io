"""Own local fixtures by default; external targets must be selected explicitly."""
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path

import allure
import pytest
import requests
from selenium import webdriver
from selenium.common.exceptions import WebDriverException

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture(autouse=True)
def label_report(request):
    allure.dynamic.feature("API contracts" if "api" in request.keywords else "Browser sign-in")


@pytest.fixture(scope="session")
def base_url():
    configured = os.getenv("BASE_URL")
    if configured:
        yield configured.rstrip("/")
        return
    node = os.getenv("NODE_BINARY") or shutil.which("node")
    if not node:
        pytest.fail("Install Node.js or set NODE_BINARY to run the shared local fixture.")
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    environment = dict(os.environ, FIXTURE_PORT=str(port))
    process = subprocess.Popen(
        [node, str(ROOT / "fixtures" / "server.mjs")], env=environment,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    url = f"http://127.0.0.1:{port}"
    try:
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            if process.poll() is not None:
                pytest.fail("The shared fixture exited before becoming ready.")
            try:
                if requests.get(url + "/health", timeout=0.5).json() == {"status": "ok"}:
                    break
            except (requests.RequestException, ValueError):
                pass
            time.sleep(0.1)  # Poll server readiness, never browser behavior.
        else:
            pytest.fail("Shared fixture did not become ready within 15 seconds.")
        yield url
    finally:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)


@pytest.fixture
def api():
    with requests.Session() as session:
        yield session


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    report = (yield).get_result()
    setattr(item, "report_" + report.when, report)


@pytest.fixture
def browser(request):
    options = webdriver.ChromeOptions()
    if os.getenv("HEADLESS", "true").lower() != "false":
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1280,900")
    if os.getenv("CHROME_BINARY"):
        options.binary_location = os.environ["CHROME_BINARY"]
    driver = webdriver.Chrome(options=options)
    driver.set_page_load_timeout(20)
    try:
        yield driver
    finally:
        report = getattr(request.node, "report_call", None)
        if report and report.failed:
            screenshot_dir = Path("reports/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            name = request.node.name.replace("/", "_").replace("\\", "_") + ".png"
            try:
                image = driver.get_screenshot_as_png()
                (screenshot_dir / name).write_bytes(image)
                allure.attach(image, name="failure screenshot", attachment_type=allure.attachment_type.PNG)
            except (WebDriverException, OSError) as error:
                # Preserve the original test failure even if screenshot capture fails.
                allure.attach(type(error).__name__, name="screenshot capture issue")
        driver.quit()
