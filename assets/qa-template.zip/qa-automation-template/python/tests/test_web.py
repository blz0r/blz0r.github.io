import os

import pytest

from pages.login_page import LoginPage

pytestmark = pytest.mark.web


def test_valid_sign_in(browser, base_url):
    page = LoginPage(browser, base_url).open()
    page.sign_in("learner@example.test", "demo-pass")
    expected = "Deliberate failure-proof expectation" if os.getenv("FAILURE_DEMO") == "1" else "Welcome, Demo Learner"
    assert page.welcome() == expected


def test_invalid_sign_in(browser, base_url):
    page = LoginPage(browser, base_url).open()
    page.sign_in("learner@example.test", "incorrect")
    assert page.error() == "Email or password is incorrect"
    assert page.login_is_visible()


def test_sign_out(browser, base_url):
    page = LoginPage(browser, base_url).open()
    page.sign_in("learner@example.test", "demo-pass")
    assert page.welcome() == "Welcome, Demo Learner"
    page.sign_out()
    assert page.login_is_visible()
    assert page.email_value() == ""
