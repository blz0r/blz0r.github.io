"""Same local API acceptance cases as the JavaScript and Java versions."""
import pytest
from jsonschema import validate

pytestmark = pytest.mark.api

TASK_SCHEMA = {
    "type": "object", "required": ["tasks"], "additionalProperties": False,
    "properties": {"tasks": {"type": "array", "minItems": 1, "items": {
        "type": "object", "required": ["id", "title", "completed"],
        "additionalProperties": False,
        "properties": {"id": {"type": "integer"}, "title": {"type": "string"},
                       "completed": {"type": "boolean"}},
    }}},
}


def test_health(api, base_url):
    response = api.get(base_url + "/health", timeout=5)
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_tasks_schema(api, base_url):
    response = api.get(base_url + "/api/tasks", timeout=5)
    assert response.status_code == 200
    validate(response.json(), TASK_SCHEMA)
    assert [task["id"] for task in response.json()["tasks"]] == [1, 2]


def test_valid_login(api, base_url):
    response = api.post(base_url + "/api/login", json={
        "email": "learner@example.test", "password": "demo-pass"}, timeout=5)
    assert response.status_code == 200
    assert response.json()["user"] == {"name": "Demo Learner", "email": "learner@example.test"}
    assert "password" not in response.text


@pytest.mark.parametrize("email,password", [
    ("learner@example.test", "incorrect"), ("unknown@example.test", "demo-pass"),
])
def test_invalid_login(api, base_url, email, password):
    response = api.post(base_url + "/api/login", json={"email": email, "password": password}, timeout=5)
    assert response.status_code == 401
    assert response.json() == {"error": "Email or password is incorrect"}


@pytest.mark.parametrize("payload", [{}, {"email": "learner@example.test"}])
def test_missing_fields(api, base_url, payload):
    response = api.post(base_url + "/api/login", json=payload, timeout=5)
    assert response.status_code == 400
    assert response.json() == {"error": "Email and password are required"}


def test_malformed_json(api, base_url):
    response = api.post(base_url + "/api/login", data="not-json",
                        headers={"Content-Type": "application/json"}, timeout=5)
    assert response.status_code == 400
    assert response.json() == {"error": "Invalid JSON"}


def test_unknown_route(api, base_url):
    response = api.get(base_url + "/missing", timeout=5)
    assert response.status_code == 404
    assert response.json() == {"error": "Not found"}
