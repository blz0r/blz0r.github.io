"""A small unittest-style suite executed by pytest with shared fixtures.

This makes the transition from older unittest QA scripts visible without
duplicating the browser suite or introducing a second server lifecycle.
"""
import unittest

import pytest
import requests


@pytest.fixture(scope="class")
def unittest_context(request, base_url):
    request.cls.base_url = base_url


@pytest.mark.api
@pytest.mark.usefixtures("unittest_context")
class TestUnittestStyle(unittest.TestCase):
    def test_health_uses_unittest_assertions(self):
        response = requests.get(self.base_url + "/health", timeout=5)
        self.assertEqual(200, response.status_code)
        self.assertEqual({"status": "ok"}, response.json())

    def test_unknown_route_uses_unittest_assertions(self):
        response = requests.get(self.base_url + "/unknown", timeout=5)
        self.assertEqual(404, response.status_code)
        self.assertIn("error", response.json())
