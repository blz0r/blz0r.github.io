# Python QA version

This version uses **pytest, Selenium, Requests, JSON Schema, unittest-style assertions, Ruff and Allure** against the same synthetic application as the TypeScript and Java versions. It is new public demonstration code, not an unmodified historical employer project.

## Run

Use Python 3.12+ with Chrome installed. Install Node.js 24 for the shared fixture. From this directory:

```text
python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest
```

The tests start and stop their own local fixture. `NODE_BINARY` can select a specific Node executable. Selenium Manager resolves the Chrome driver; first execution may download it.

```text
python -m pytest -m api
python -m pytest -m web
python -m ruff check pages tests
```

Only set `BASE_URL` when you intend to test a compatible application you are authorized to use. The provided selectors and login values are specific to the synthetic fixture; adapt them for your app. Setting BASE_URL disables automatic fixture startup.

## Results and extension points

- JUnit XML: `reports/junit/results.xml`
- Allure raw results: `reports/allure-results`
- Browser failure screenshots: `reports/screenshots`
- Page objects: `pages/login_page.py`
- Parameterized API cases: `tests/test_api.py`
- Fixtures and failure attachment hook: `tests/conftest.py`
- Legacy-style assertion example: `tests/test_unittest_style.py`, run through pytest so it can reuse the fixture lifecycle

`requirements.in` lists the direct tools. `requirements.txt` pins the environment used for verification. After intentionally updating dependencies in a fresh virtual environment, run the tests and refresh the pins with `python -m pip freeze > requirements.txt`.

Generate HTML from Allure raw results with an installed compatible Allure CLI. Raw JSON and attachments alone are not an HTML report. See the shared usage guide for report commands and prerequisites.

For a controlled screenshot-hook demonstration on the local fixture only, set `FAILURE_DEMO=1` and run `python -m pytest -m web -k valid_sign_in`. This deliberately exits with a failed assertion. Unset FAILURE_DEMO afterward and rerun normally. Never mix that proof run into reported passing results.

The API uses synthetic data, no database and no production authentication. Test logs and screenshots from your own real applications may contain sensitive information; review them before sharing.

## Verified locally

On 2026-10-25, Python 3.12.1 and headless Chrome 156 completed all **14 tests** and Ruff checks. A separate deliberate failure verified PNG screenshots and Allure attachments. Allure HTML generation produced a final report with 14 passing tests. See [the verification record](../docs/VALIDATION.md) for limits and the other stacks.
