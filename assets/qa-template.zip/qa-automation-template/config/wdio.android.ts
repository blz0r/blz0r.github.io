import { config as local, projectPath } from './wdio.local.ts';
import { isAbsolute } from 'node:path';
import { existsSync } from 'node:fs';

if (process.env.ALLOW_MOBILE !== 'true') throw new Error('Mobile is disabled. Set ALLOW_MOBILE=true only for an authorized local device.');
for (const name of ['ANDROID_UDID', 'ANDROID_DEVICE_NAME', 'ANDROID_APP', 'ANDROID_READY_ID']) {
  if (!process.env[name]) throw new Error(`Android example requires ${name}`);
}
if (!isAbsolute(process.env.ANDROID_APP!) || !existsSync(process.env.ANDROID_APP!)) {
  throw new Error('ANDROID_APP must be an existing absolute path to your authorized sample APK.');
}
const host = process.env.APPIUM_HOST || '127.0.0.1';
if (!['localhost', '127.0.0.1'].includes(host)) throw new Error('This example permits only a local Appium server.');

export const config: WebdriverIO.Config = {
  ...local,
  specs: [projectPath('tests/mobile/launch.feature')],
  cucumberOpts: { require: [projectPath('tests/mobile/**/*.steps.ts')], timeout: 30000 },
  hostname: host,
  port: Number(process.env.APPIUM_PORT || 4723),
  path: '/',
  capabilities: [{
    platformName: 'Android',
    'appium:automationName': 'UiAutomator2',
    'appium:udid': process.env.ANDROID_UDID,
    'appium:deviceName': process.env.ANDROID_DEVICE_NAME,
    'appium:app': process.env.ANDROID_APP,
    'appium:noReset': false
  }]
};
