import 'dotenv/config';
import { mkdir } from 'node:fs/promises';
import { browser } from '@wdio/globals';
import { fileURLToPath } from 'node:url';

export const projectPath = (relative: string) => fileURLToPath(new URL(`../${relative}`, import.meta.url));

export const config: WebdriverIO.Config = {
  runner: 'local',
  tsConfigPath: projectPath('tsconfig.json'),
  specs: [projectPath('tests/features/**/*.feature')],
  maxInstances: 1,
  capabilities: [{
    browserName: 'chrome',
    'goog:chromeOptions': {
      ...(process.env.CHROME_BINARY ? { binary: process.env.CHROME_BINARY } : {}),
      args: ['--headless=new', '--disable-dev-shm-usage', '--window-size=1280,900']
    }
  }],
  logLevel: 'warn',
  baseUrl: process.env.BASE_URL || 'http://127.0.0.1:4173',
  waitforTimeout: 5000,
  connectionRetryTimeout: 60000,
  connectionRetryCount: 1,
  framework: 'cucumber',
  reporters: [
    'spec',
    ['junit', { outputDir: './reports/junit', outputFileFormat: ({ cid }) => `web-${cid}.xml` }],
    ['allure', { outputDir: './reports/allure-results', useCucumberStepReporter: true,
      disableWebdriverStepsReporting: true, disableWebdriverScreenshotsReporting: false }]
  ],
  cucumberOpts: { require: [projectPath('tests/steps/**/*.ts')], timeout: 15000, failFast: false },
  afterScenario: async function (_world, result) {
    if (!result.passed) {
      await mkdir('./reports/screenshots', { recursive: true });
      await browser.saveScreenshot(`./reports/screenshots/failure-${Date.now()}.png`);
    }
  }
};
