import { config as local } from './wdio.local.ts';
import { browser } from '@wdio/globals';

if (process.env.ALLOW_CLOUD !== 'true') throw new Error('Cloud is disabled. Set ALLOW_CLOUD=true only for an authorized account/run.');
for (const name of ['BROWSERSTACK_USERNAME', 'BROWSERSTACK_ACCESS_KEY', 'CLOUD_BASE_URL']) {
  if (!process.env[name]) throw new Error(`Cloud example requires ${name}`);
}
const target = new URL(process.env.CLOUD_BASE_URL!);
const tunnel = process.env.BROWSERSTACK_LOCAL === 'true';
if (tunnel && (!process.env.BROWSERSTACK_LOCAL_IDENTIFIER || target.href !== 'http://127.0.0.1:4173/')) {
  throw new Error('Tunnel mode requires a local identifier and the synthetic fixture at http://127.0.0.1:4173/');
}
if (!tunnel && (target.protocol !== 'https:' || ['localhost', '127.0.0.1'].includes(target.hostname))) {
  throw new Error('CLOUD_BASE_URL must be an authorized HTTPS deployment reachable by BrowserStack.');
}

// The manual cloud workflow owns and closes a tunnel on its disposable runner.
export const config: WebdriverIO.Config = {
  ...local,
  user: process.env.BROWSERSTACK_USERNAME,
  key: process.env.BROWSERSTACK_ACCESS_KEY,
  hostname: 'hub.browserstack.com',
  protocol: 'https',
  port: 443,
  path: '/wd/hub',
  baseUrl: target.href,
  capabilities: [{
    browserName: 'Chrome',
    browserVersion: 'latest',
    'bstack:options': {
      os: 'Windows', osVersion: '11', projectName: 'Synthetic QA template',
      buildName: process.env.BROWSERSTACK_BUILD_NAME || 'Manual QA verification',
      sessionName: 'Practice login', debug: true,
      ...(tunnel ? { local: true, localIdentifier: process.env.BROWSERSTACK_LOCAL_IDENTIFIER } : {})
    }
  }],
  after: async function (result) {
    await browser.execute('browserstack_executor: ' + JSON.stringify({
      action: 'setSessionStatus', arguments: {
        status: result === 0 ? 'passed' : 'failed', reason: 'Cucumber runner exit status: ' + result
      }
    }));
  }
};
