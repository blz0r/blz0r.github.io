import { config as local, projectPath } from './wdio.local.ts';
import { isAbsolute } from 'node:path';
import { existsSync } from 'node:fs';

if (process.env.ALLOW_MOBILE !== 'true') throw new Error('Android mobile tests are opt-in. Set ALLOW_MOBILE=true only in the authorized CI job.');

for (const name of ['ANDROID_UDID', 'ANDROID_DEVICE_NAME', 'ANDROID_APP']) {
  if (!process.env[name]) throw new Error('Android CI requires ' + name);
}
if (!isAbsolute(process.env.ANDROID_APP!) || !existsSync(process.env.ANDROID_APP!)) {
  throw new Error('ANDROID_APP must be an existing absolute path to the verified ApiDemos sample APK.');
}

export const config: WebdriverIO.Config = {
  ...local,
  specs: [projectPath('tests/mobile/apidemos.feature')],
  cucumberOpts: { require: [projectPath('tests/mobile/apidemos.steps.ts')], timeout: 30000 },
  hostname: '127.0.0.1',
  port: 4723,
  path: '/',
  connectionRetryCount: 1,
  connectionRetryTimeout: 60000,
  reporters: [
    'spec',
    ['junit', { outputDir: './reports/junit', outputFileFormat: ({ cid }) => 'android-' + cid + '.xml' }],
    ['allure', { outputDir: './reports/allure-results', useCucumberStepReporter: true,
      disableWebdriverStepsReporting: true, disableWebdriverScreenshotsReporting: false }]
  ],
  capabilities: [{
    platformName: 'Android',
    'appium:automationName': 'UiAutomator2',
    'appium:udid': process.env.ANDROID_UDID,
    'appium:deviceName': process.env.ANDROID_DEVICE_NAME,
    'appium:app': process.env.ANDROID_APP,
    'appium:appPackage': 'io.appium.android.apis',
    'appium:noReset': false,
    'appium:newCommandTimeout': 120
  }]
};
