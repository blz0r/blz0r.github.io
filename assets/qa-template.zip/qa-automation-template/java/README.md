# Java QA example

The same synthetic requirements expressed with **Java 17+**, **Selenium**, **Cucumber**, **TestNG**, **REST Assured** and **Allure**. Maven compiles the tests for Java 17. Dependencies and build plugins are pinned in `pom.xml`.

## Run

Use a working JDK 17+ and Maven 3.8+ (a current Maven 3.9 release is suitable), with Chrome installed. In a first terminal, start the shared fixture from the project root:

```sh
npm run fixture
```

In a second terminal:

```sh
cd java
mvn clean test
```

Run API checks only with `mvn test -Dtest=ApiContractTest` or browser scenarios only with `mvn test -Dtest=RunCucumberTest`. Selenium Manager may download a compatible driver. `CHROME_BINARY` can override the Chrome location. Set `SE_CACHE_PATH` if the driver/browser cache needs a dedicated folder.

The default fixture URL is `http://127.0.0.1:4173`. An authorized target with the same contract can be selected with `mvn test -DbaseUrl=http://127.0.0.1:4174` or `BASE_URL`. Java reads environment variables and system properties directly; it does not load the root `.env` file. The fixture must already be running. The root GitHub workflow starts it for CI.

## Structure and reports

- `RunCucumberTest`: TestNG runner for three Cucumber browser cases.
- `steps/`: browser setup/cleanup, assertions and failure screenshot hook.
- `pages/`: selectors, explicit waits and browser actions.
- `ApiContractTest`: seven REST Assured checks for health, login outcomes, validation, tasks and 404.
- `target/surefire-reports/`: XML and TestNG reports.
- `target/cucumber.html` and `target/cucumber.json`: browser scenario reports.
- `target/allure-results/`: Allure results for API and browser tests.
- `target/screenshots/`: failure screenshots, also attached to Cucumber and Allure.

Allure uses its runtime lambda-step and attachment APIs, so no AspectJ agent is needed. From the project root, run `npm run report:java` to generate `reports/allure-java/index.html` using the bundled Node-based Allure 3 CLI. Clean generated results between runs with `mvn clean test`; do not commit `target/`.

Surefire 3.5.4 is intentionally pinned for its native TestNG provider. The 3.6.1 JUnit Platform bridge produced duplicate Allure lifecycle results in local verification; 3.5.4 produces one result per test.

Cucumber 8 marks its TestNG runner integration deprecated for future removal. This pinned example retains it to demonstrate the requested TestNG integration; plan a runner migration before upgrading across a version that removes it.

This example uses only invented accounts and the original shared fixture. It does not call cloud providers or mobile devices. Functional sample tests do not establish production security, accessibility, performance or exhaustive browser coverage.

## Verified status

On 2026-10-25 (America/Chicago), JDK 18.0.1.1 targeting Java 17, Maven 3.8.4 and headless Chrome 156 completed **10 tests: 3 browser scenarios and 7 API checks** with no failures or skips. Allure emitted exactly ten test result files. A deliberate temporary assertion mismatch also verified failure PNGs and Cucumber/Allure attachments; the temporary failing scenario is not shipped. Chrome 156 emitted a nearest-CDP-version warning (Selenium provided 155); these tests use standard WebDriver commands and passed. No CDP-specific behavior is claimed.

## References

- [Cucumber-JVM installation](https://cucumber.io/docs/installation/java/)
- [Selenium WebDriver](https://www.selenium.dev/documentation/webdriver/)
- [TestNG](https://testng.org/)
- [REST Assured](https://rest-assured.io/)
- [Allure TestNG](https://allurereport.org/docs/testng/)
