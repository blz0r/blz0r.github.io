package example.steps;

import example.TestSettings;
import example.pages.LoginPage;
import example.pages.DashboardPage;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.qameta.allure.Allure;
import io.qameta.allure.AttachmentOptions;
import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

public final class LoginSteps {
    private WebDriver driver;
    private LoginPage login;
    private DashboardPage dashboard;
    @Before public void start(Scenario scenario) {
        Allure.getLifecycle().updateTest(test -> test.setName(scenario.getName()));
        Allure.parameter("scenario", scenario.getName());
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new", "--window-size=1280,900", "--disable-dev-shm-usage");
        String binary = System.getenv("CHROME_BINARY");
        if (binary != null && !binary.isBlank()) options.setBinary(binary);
        driver = new ChromeDriver(options);
        login = new LoginPage(driver);
        dashboard = new DashboardPage(driver);
    }
    @After public void stop(Scenario scenario) throws Exception {
        try {
            if (scenario.isFailed() && driver != null) {
                byte[] png = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                Files.createDirectories(Path.of("target/screenshots"));
                Files.write(Path.of("target/screenshots/failure-" + System.nanoTime() + ".png"), png);
                scenario.attach(png, "image/png", "Failure screenshot");
                Allure.attachment("Failure screenshot", "image/png", new ByteArrayInputStream(png), AttachmentOptions.withFileExtension(".png"));
            }
        } finally { if (driver != null) driver.quit(); }
    }
    @Given("I open the practice login page") public void open() {
        Allure.step("Open practice login", () -> login.open(TestSettings.baseUrl()));
    }
    @When("I sign in with {string} and {string}") public void signIn(String email, String password) {
        Allure.step("Sign in with synthetic demo data", () -> login.signIn(email, password));
    }
    @Then("I see the welcome message {string}") public void welcome(String message) {
        Allure.step("Verify welcome", () -> Assert.assertEquals(dashboard.welcome(), message));
    }
    @Then("I see the two practice tasks") public void tasks() {
        Allure.step("Verify tasks", () -> Assert.assertEquals(dashboard.tasks(), List.of("Review acceptance criteria", "Run regression checks")));
    }
    @When("I sign out") public void signOut() { Allure.step("Sign out", () -> dashboard.signOut()); }
    @Then("I see an empty login form") public void emptyForm() {
        Allure.step("Verify signed-out form", () -> {
            Assert.assertTrue(login.visible("login-panel"));
            Assert.assertEquals(login.value("email"), "");
            Assert.assertEquals(login.value("password"), "");
            Assert.assertFalse(login.visible("dashboard"));
        });
    }
    @Then("I see the error {string}") public void error(String message) {
        Allure.step("Verify credential error", () -> Assert.assertEquals(login.error(), message));
    }
    @Then("the dashboard stays hidden") public void hidden() {
        Allure.step("Verify dashboard remains hidden", () -> Assert.assertFalse(login.visible("dashboard")));
    }
}
