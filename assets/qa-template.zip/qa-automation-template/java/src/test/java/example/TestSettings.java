package example;

public final class TestSettings {
    private TestSettings() { }
    public static String baseUrl() {
        return System.getProperty("baseUrl", System.getenv().getOrDefault("BASE_URL", "http://127.0.0.1:4173"));
    }
}
