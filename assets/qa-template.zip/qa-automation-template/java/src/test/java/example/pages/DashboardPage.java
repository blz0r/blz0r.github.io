package example.pages;

import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public final class DashboardPage {
    private final WebDriver driver;
    public DashboardPage(WebDriver driver) { this.driver = driver; }
    public String welcome() {
        return new WebDriverWait(driver, Duration.ofSeconds(5))
            .until(ExpectedConditions.visibilityOfElementLocated(LoginPage.id("welcome"))).getText();
    }
    public List<String> tasks() {
        return driver.findElements(By.cssSelector("[data-testid='tasks'] li")).stream().map(WebElement::getText).toList();
    }
    public void signOut() { driver.findElement(LoginPage.id("sign-out")).click(); }
}
