package example.pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public final class LoginPage {
    private final WebDriver driver;
    private final WebDriverWait wait;
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }
    public static By id(String id) { return By.cssSelector("[data-testid='" + id + "']"); }
    public void open(String baseUrl) { driver.get(baseUrl); }
    public void signIn(String email, String password) {
        driver.findElement(id("email")).sendKeys(email);
        driver.findElement(id("password")).sendKeys(password);
        driver.findElement(id("sign-in")).click();
    }
    public String error() { return wait.until(ExpectedConditions.visibilityOfElementLocated(id("error"))).getText(); }
    public boolean visible(String id) { return driver.findElement(id(id)).isDisplayed(); }
    public String value(String id) { return driver.findElement(id(id)).getDomProperty("value"); }
}
