package example;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import io.qameta.allure.Allure;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

public class ApiContractTest {
    private RequestSpecification request() {
        return given().baseUri(TestSettings.baseUrl()).contentType("application/json");
    }
    @Test public void healthIsReady() {
        Allure.step("Health contract", () -> request().get("/health").then().statusCode(200)
            .contentType("application/json").body("status", equalTo("ok")));
    }
    @Test public void validLoginReturnsPublicUser() {
        Allure.step("Valid synthetic login", () -> request().body("{\"email\":\"learner@example.test\",\"password\":\"demo-pass\"}")
            .post("/api/login").then().statusCode(200).body("user.name", equalTo("Demo Learner"),
                "user.email", equalTo("learner@example.test"), "user.password", nullValue()));
    }
    @Test public void wrongPasswordReturnsUnauthorized() {
        Allure.step("Invalid synthetic login", () -> request().body("{\"email\":\"learner@example.test\",\"password\":\"wrong-pass\"}")
            .post("/api/login").then().statusCode(401).body("error", equalTo("Email or password is incorrect"), "user", nullValue()));
    }
    @Test public void missingFieldsReturnBadRequest() {
        Allure.step("Required fields", () -> request().body("{\"email\":\"learner@example.test\"}").post("/api/login")
            .then().statusCode(400).body("error", equalTo("Email and password are required")));
    }
    @Test public void malformedJsonReturnsBadRequest() {
        Allure.step("Malformed input", () -> request().body("{invalid").post("/api/login")
            .then().statusCode(400).body("error", equalTo("Invalid JSON")));
    }
    @Test public void taskContractIsStable() {
        Allure.step("Task contract", () -> request().get("/api/tasks").then().statusCode(200)
            .body("tasks.id", contains(1, 2), "tasks.title", contains("Review acceptance criteria", "Run regression checks"),
                "tasks.completed", contains(true, false)));
    }
    @Test public void unknownRouteReturnsNotFound() {
        Allure.step("Unknown route", () -> request().get("/missing").then().statusCode(404).body("error", equalTo("Not found")));
    }
}
