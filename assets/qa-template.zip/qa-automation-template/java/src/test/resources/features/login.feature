Feature: Synthetic practice workspace
  Background:
    Given I open the practice login page

  @smoke @positive
  Scenario: A demo user sees their tasks and can sign out
    When I sign in with "learner@example.test" and "demo-pass"
    Then I see the welcome message "Welcome, Demo Learner"
    And I see the two practice tasks
    When I sign out
    Then I see an empty login form

  @negative
  Scenario Outline: Incorrect credentials for <email> do not open the dashboard
    When I sign in with "<email>" and "<password>"
    Then I see the error "Email or password is incorrect"
    And the dashboard stays hidden

    Examples:
      | email                  | password   |
      | learner@example.test   | wrong-pass |
      | unknown@example.test   | demo-pass  |
